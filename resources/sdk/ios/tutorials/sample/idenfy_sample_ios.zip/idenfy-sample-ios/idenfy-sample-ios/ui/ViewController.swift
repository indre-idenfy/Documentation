//
//  ViewController.swift
//  idenfy-sample-ios
//
//  Created by Viktor Vostrikov on 2020-06-22.
//  Copyright © 2020 Viktor Vostrikov. All rights reserved.
//

import iDenfySDK
import idenfyviews
import UIKit

class ViewController: UIViewController {
    lazy var getIdenfyAuthTokenUseCase = GetIdenfyAuthTokenUseCase(apiHelper: APIHelper())
    private let errorAlert = CustomAlert(title: NSLocalizedString("idenfy_sample_app_loading_view_title", tableName: nil, bundle: Bundle.main, value: "", comment: ""), canCancel: true)

    private let loadingAlert = CustomAlert(title: NSLocalizedString("idenfy_sample_app_loading_view_title", tableName: nil, bundle: Bundle.main, value: "", comment: ""), canCancel: false)
    var appLanguage: AppLanguage!
    var beginIdentificationButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        setIdenfyAuthTokenState(IdenfyAuthTokenState.NotStarted)
        appLanguage = AppLanguage(Locale.preferredLanguages[0])
        appLanguage.languageEnum = "en"
        let sampleAppView = SampleAppView()
        sampleAppView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(sampleAppView)
        sampleAppView.anchor(top: view.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor)
        beginIdentificationButton = sampleAppView.beginIdentificationButton
        beginIdentificationButton.addTarget(self, action: #selector(beginIdentificationPressed), for: .touchUpInside)
        beginIdentificationButton.setTitle("idenfy_sample_app_button_title".localized(appLanguage.languageEnum), for: UIControl.State.normal)

        sampleAppView.sampleAppDesciption.text = "idenfy_sample_app_description".localized(appLanguage.languageEnum)
        sampleAppView.sampleAppTitle.text = "idenfy_sample_app_title".localized(appLanguage.languageEnum)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyGradients()
    }

    private func applyGradients() {
        beginIdentificationButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }

    @objc private func beginIdentificationPressed() {
        getIdenfyAuthToken()
    }

    private func getIdenfyAuthToken() {
        setIdenfyAuthTokenState(IdenfyAuthTokenState.Loading)
        let authTokenBody = AuthTokenBody(clientId: Consts.clientId)
        getIdenfyAuthTokenUseCase.execute(authTokenBody: authTokenBody, appLanguage: appLanguage, success: { authToken in

            self.setIdenfyAuthTokenState(IdenfyAuthTokenState.Success(authToken: authToken))
        }) { errorResponse in
            self.setIdenfyAuthTokenState(IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: errorResponse.message))
        }
    }

    private func setIdenfyAuthTokenState(_ idenfyAuthTokenState: IdenfyAuthTokenState) {
        switch idenfyAuthTokenState {
        case .Loading:
            presentLoadingAlert()

        case .NotStarted: break

        case let .AuthTokenCouldNotBeReceived(error: error):
            print("Error receiving token: \(error)")
            presentErrorAlert(error)

        case let .Success(authToken: authToken):
            dismissLoadingAlert()
            initializeIdenfySDK(authToken: authToken.authToken)
        }
    }

    private func presentErrorAlert(_ error: String) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            self.errorAlert.alertTitle.text = error
            self.dismissLoadingAlert()
            self.errorAlert.show(animated: false)
        }
    }

    private func presentLoadingAlert() {
        loadingAlert.loadingImage.play()
        loadingAlert.show(animated: false)
    }

    private func dismissLoadingAlert() {
        loadingAlert.dismiss(animated: false)
    }

    private func initializeIdenfySDK(authToken: String) {
        let idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .withInstructions(true)
            .build()

        let idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withUISettingsV2(idenfyUISettingsV2)
            .build()

        let idenfyController = IdenfyController.shared
        idenfyController.initializeIdenfySDKV2(idenfySettingsV2: idenfySettingsV2)
        let idenfyVC = idenfyController.instantiateNavigationController()

        present(idenfyVC, animated: true, completion: nil)
        idenfyController.handleIDenfyCallbacks(
            onSuccess: { AuthenticationResultResponse
                in

                let encoder = JSONEncoder()
                encoder.outputFormatting = []

                do {
                    let jsonData = try encoder.encode(AuthenticationResultResponse)

                    if let jsonString = String(data: jsonData, encoding: .utf8)?.replacingOccurrences(of: "\\/", with: "") {
                        print(jsonString)
                    }
                } catch {
                    print(error.localizedDescription)
                }
                switch AuthenticationResultResponse.idenfyIdentificationStatus {
                case .APPROVED:
                    print("Success!")
                            // User has been approved successfully.

                case .DENIED:
                    // Identification has been denied. Retrieving error message:
                    let response = AuthenticationResultResponse.errorMessage?.en
                    print(response as Any)
                    idenfyVC.dismiss(animated: false, completion: nil)

                case .SUSPECTED:
                    print("Identification Suspected")
                                                            // User has been suspected

                case .REVIEWING:

                    print("Identification of a user is being reviewed manually")

                        @unknown default: break
                }

            },
            onError: { IdenfyErrorResponse in

                do {
                    let encoder = JSONEncoder()
                    encoder.outputFormatting = []
                    let jsonData = try encoder.encode(IdenfyErrorResponse)

                    if let jsonString = String(data: jsonData, encoding: .utf8)?.replacingOccurrences(of: "\\/", with: "") {
                        print(jsonString)
                    }
                } catch {
                    print(error.localizedDescription)
                }
                print(IdenfyErrorResponse.message)
            }, onUserExit: {
                print("onUserExit")
            }
        )
    }
}
