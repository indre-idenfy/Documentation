package com.idenfy.idenfy_sample_android.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.idenfy.idenfySdk.CoreSdkInitialization.IdenfyController
import com.idenfy.idenfySdk.SdkResponseModels.AutenticationResult.AuthenticationResultResponse
import com.idenfy.idenfySdk.SdkResponseModels.IdenfyErrorResponse
import com.idenfy.idenfySdk.api.initialization.IdenfySettingsV2.IdenfyBuilderV2
import com.idenfy.idenfySdk.api.logging.IdenfySDKLoggingSettings.IdenfySDKLoggingEnum
import com.idenfy.idenfySdk.api.ui.IdenfyUISettingsV2.IdenfyUIBuilderV2
import com.idenfy.idenfy_sample_android.R
import com.idenfy.idenfy_sample_android.data.models.AuthToken
import com.idenfy.idenfy_sample_android.ui.presentation.IdenfyAuthTokenState
import com.idenfy.idenfy_sample_android.ui.viewmodel.MainViewModel

@Suppress("NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")
class MainActivity : AppCompatActivity() {
    private lateinit var mainViewModel: MainViewModel
    private lateinit var btnBeginIdentification: Button
    private var loadingDialog: AlertDialog? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainViewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        setContentView(R.layout.idenfy_activity_sample_app_main)
        btnBeginIdentification =
            findViewById(R.id.idenfy_button_sample_app_view_begin_identification)
        btnBeginIdentification.setOnClickListener {
            mainViewModel.getIdenfyAuthToken()
        }
        observeIdenfyAuthTokenState()
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == IdenfyController.IDENFY_REQUEST_CODE) {
            when (resultCode) {
                IdenfyController.AUTHENTICATION_RESULT_CODE -> {
                    //Identification completed response
                    val authenticationResultResponse: AuthenticationResultResponse =
                        data!!.getParcelableExtra(IdenfyController.ON_AUTHENTICATION_RESULT)
                    Toast.makeText(this, authenticationResultResponse.toString(), Toast.LENGTH_LONG)
                        .show()
                    Log.d("SDKResponse", authenticationResultResponse.toString())
                }
                IdenfyController.ERROR_CODE -> {
                    //Error response
                    val idenfyErrorResponse: IdenfyErrorResponse =
                        data!!.getParcelableExtra(IdenfyController.ON_ERROR)
                    Toast.makeText(this, idenfyErrorResponse.toString(), Toast.LENGTH_LONG).show()
                    Log.d("SDKResponse", idenfyErrorResponse.toString())
                }
                IdenfyController.USER_EXIT_CODE -> {
                    //User exited the SDK
                    Toast.makeText(this, "user exit", Toast.LENGTH_LONG).show()
                    Log.d("SDKResponse", "user exit")
                }
            }
        }
    }

    private fun observeIdenfyAuthTokenState() {
        mainViewModel.idenfyAuthTokenStateLiveData.observe(this, Observer {
            when (it) {
                IdenfyAuthTokenState.NotStarted -> {

                }
                IdenfyAuthTokenState.Loading -> {
                    handleLoadingAuthTokenState()
                }
                is IdenfyAuthTokenState.AuthTokenCouldNotBeReceived -> {
                    handleAuthTokenCouldNotBeReceived(it.throwable)
                }
                is IdenfyAuthTokenState.Success -> {
                    handleAuthTokenSuccess(it.authToken)

                }
            }
        })

    }

    private fun handleAuthTokenSuccess(authToken: AuthToken) {
        mainViewModel.resetAuthTokenState()
        loadingDialog?.cancel()
        initializeIdenfySDK(this, authToken.authToken)
    }

    private fun handleAuthTokenCouldNotBeReceived(throwable: Throwable) {
        mainViewModel.resetAuthTokenState()
        loadingDialog?.cancel()
        Toast.makeText(this, "Error obtaining token $throwable", Toast.LENGTH_LONG).show()
    }

    private fun handleLoadingAuthTokenState() {
        val builder = AlertDialog.Builder(this, com.idenfySdk.R.style.IdenfyStyleAlertDialog)
        val inflater = this.layoutInflater
        val dialogView: View = inflater.inflate(
            R.layout.idenfy_dialog_sample_app,
            null
        )
        builder.setView(dialogView)
        loadingDialog = builder.create()
        loadingDialog!!.setCancelable(false)
        loadingDialog!!.show()
    }

    private fun initializeIdenfySDK(activity: Activity, authToken: String) {
        val idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .withInstructions(true)
            .build()
        val idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withIdenfyUISettingsV2(idenfyUISettingsV2)
            .withLogging(IdenfySDKLoggingEnum.FULL)
            .build()
        IdenfyController.getInstance().startActivityForResultV2(
            activity,
            IdenfyController.IDENFY_REQUEST_CODE,
            idenfySettingsV2
        )
    }


}